import java.io.FileReader
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.google.gson.reflect.TypeToken
import java.io.File
import java.text.DecimalFormat
import java.text.NumberFormat
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

class RepositoryLaptop {
    private val gson = Gson()
    private val mutableListType = object : TypeToken<MutableList<Laptop>>() {}.type!!    // untuk mendefinisikan tipe
    private var laptopList: MutableList<Laptop> = gson.fromJson(FileReader("src/assets/DataLaptop.json"), mutableListType)    // untuk menguraikan json menjadi list

    private var fileDataLaptop = File("src/assets/DataLaptop.json")             // deklarasi file

    private val gsonPresentableWrite = GsonBuilder().setPrettyPrinting().create()!!      // untuk mengubah list berisi objek menjadi json string yang mudah dibaca
    private var jsonLaptopList: String = gsonPresentableWrite.toJson(laptopList)         // laptopList diubah menjadi json string

    private var laptopListTemporary = LaptopListTemporary()        // objek yang berisi list temporary
    private var laptopTemporary = LaptopTemporary()                // objek yang berisi variable temporary

    private fun time():String {return LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS"))}
    private fun Long.toRupiah():String{
        val formatter: NumberFormat = DecimalFormat("#,###")
        val moneyRupiah = formatter.format(this)
        return "Rp $moneyRupiah"
    }

    fun getAllPrice():Long{ // untuk mendapatkan harga semua laptop
        var totalHarga:Long = 0
        laptopList.forEach { totalHarga+= it.harga * it.stok }
        return totalHarga
    }

    fun addLaptopNew(financialReports: FinancialReports, transactionReports: TrasactionReports){
        var k = 0
        var sign = false
        laptopTemporary.totalHarga = 0
        laptopTemporary.totalStok = 0

        print("\nBerapa Tipe Laptop Yang Ingin Ditambah : ")
        laptopTemporary.totalTipe = readLine()?.toInt()?:0

        while ( k < laptopTemporary.totalTipe) {
            while(!sign){
                sign = true
                println("\nLaptop Ke-${k+1}")
                print("Masukan Merek Laptop          : ")
                laptopTemporary.merek = readLine() ?: "NoName"
                print("Masukan Tipe Laptop           : ")
                laptopTemporary.tipe = readLine() ?: "NoName"
                for(i in 0 until laptopList.count()){
                    if(laptopList[i].merek == laptopTemporary.merek
                            && laptopList[i].tipe == laptopTemporary.tipe){
                        println("\nLaptop Tersebut Sudah Ada !!!, Masukan Kembali Laptop Dengan Benar")
                        sign = false
                    }
                }
            }
            print("Masukan Tipe Processor Laptop : ")
            laptopTemporary.processor = readLine() ?: "NoName"
            print("Masukan Ukuran Ram Laptop     : ")
            laptopTemporary.ram = readLine() ?.toInt() ?: 0
            print("Masukan Ukuran Rom Laptop     : ")
            laptopTemporary.rom = readLine()?.toInt() ?: 0
            print("Tipe VGA Laptop               : ")
            laptopTemporary.vga = readLine() ?: "NoName"
            print("Masukan Stok Laptop           : ")
            laptopTemporary.stok = readLine() ?.toInt() ?: 0
            print("Masukan Harga Laptop          : ")
            laptopTemporary.harga = readLine() ?.toLong() ?: 0
            println("Total Uang Anda               : ${financialReports.getMoneyTotal().toRupiah()}")
            println("Harga Total                   : ${(laptopTemporary.harga*laptopTemporary.stok).toRupiah()}")
            if(laptopTemporary.harga*laptopTemporary.stok > financialReports.getMoneyTotal()){
                println("\nUangnya Kaga Cukup !!! ")
                sign = false
                continue
            }
            print("\nApakah Anda Sudah Yakin [Y/N] : ") // untuk pengecekan oleh user
            when (readLine() ?: "") {
                "Y" -> {
                    k++
                    laptopList.add(Laptop(
                            laptopTemporary.merek,
                            laptopTemporary.tipe,
                            laptopTemporary.processor,
                            laptopTemporary.ram,
                            laptopTemporary.rom,
                            laptopTemporary.vga,
                            laptopTemporary.stok,
                            laptopTemporary.harga
                    ))
                    laptopTemporary.totalHarga += laptopTemporary.harga * laptopTemporary.stok
                    laptopTemporary.totalStok += laptopTemporary.stok
                    financialReports.setMoneyTotal(financialReports.getMoneyTotal() - laptopTemporary.harga * laptopTemporary.stok)
                    financialReports.jsonMoneyTotal = financialReports.gsonPresentableWrite.toJson(financialReports.getMoneyTotalForJson())
                    financialReports.fileDataFinancial.writeText(financialReports.jsonMoneyTotal)
                    println("\nSisa Uang Anda : ${(financialReports.getMoneyTotal()).toRupiah()}")
                }
                else -> {
                    println("\nMasukan Ulang !")
                }
            }
            sign = false
            jsonLaptopList = gsonPresentableWrite.toJson(laptopList)
            fileDataLaptop.writeText(jsonLaptopList)        // untuk menulis ulang json sesuai dengan laptopList terbaru
        }
        transactionReports.buyingTransactionIn(time(), laptopTemporary.totalTipe, laptopTemporary.totalStok, laptopTemporary.totalHarga)
    }

    fun addLaptopOld(financialReports: FinancialReports, transactionReports: TrasactionReports){
        var stokLaptopYangDiTambah:Int
        var count:Int
        var k = 0
        var j = 0

        print("\nBerapa Tipe Laptop Yang Ingin Ditambah : ")
        laptopTemporary.totalTipe = readLine()?.toInt()?:0

        while( k < laptopTemporary.totalTipe) {
            laptopListTemporary.merek.clear()
            laptopListTemporary.tipe.clear()
            var sign = true
            laptopTemporary.totalStok = 0
            laptopTemporary.totalHarga = 0
            count = 1
            laptopList.forEach {
                if(!laptopListTemporary.merek.contains(it.merek))
                    laptopListTemporary.merek.add(it.merek)
                }

            println("\nLaptop Ke-${k+1}")
            println("|------|------------------|")
            println("|  No  |      Merek       |")
            println("|------|------------------|")
            laptopListTemporary.merek.forEach { System.out.format("|%4d  |   %-15s|\n",++j, it) }
            println("|------|------------------|")
            j = 0

            print("Merek Laptop Yang Ke          : ")
            var pilihan = readLine()?.toInt()?:0

            if(pilihan > laptopListTemporary.merek.count() || pilihan < 0){
                println("\nTidak Ada Di Pilihan !!!")
                continue
            }
            pilihan--
            laptopTemporary.merek = laptopListTemporary.merek[pilihan]

            println("|------|------------------|")
            println("|  No  |       Tipe       |")
            println("|------|------------------|")
            laptopList.forEach {
                if(laptopTemporary.merek == it.merek){
                    System.out.format("|%4d  |   %-15s|\n",count,it.tipe)
                    laptopListTemporary.tipe.add(it.tipe)
                    count++
                }
            }
            println("|------|------------------|")

            print("Tipe Laptop Yang Ke                        : ")
            pilihan = readLine()?.toInt()?:0
            if(pilihan > laptopListTemporary.tipe.count() || pilihan < 0){
                println("\nTidak Ada Di Pilihan !!!")
                laptopListTemporary.tipe.clear()
                continue
            }
            pilihan--
            laptopTemporary.tipe = laptopListTemporary.tipe[pilihan]

            laptopList.forEach {
                if (it.merek == laptopTemporary.merek
                        && it.tipe == laptopTemporary.tipe) {
                    println("Harga Laptop                               : ${it.harga.toRupiah()}")
                    print("Masukan Jumlah Stok Yang Ingin Ditambahkan : ")
                    stokLaptopYangDiTambah = readLine()?.toInt() ?: 0
                    println("Harga Total                                : ${(it.harga * stokLaptopYangDiTambah).toRupiah()}")
                    print("\nApakah Anda Sudah Yakin [Y/N] : ")
                    if(readLine()?:"" != "Y" || financialReports.getMoneyTotal() < it.harga * stokLaptopYangDiTambah){
                        sign = false
                    }else {
                        it.stok += stokLaptopYangDiTambah                                // stok di laptop list ditambah sesuai tipe yang ditambah
                        laptopTemporary.totalStok += stokLaptopYangDiTambah              // total stok yang ditambah dari seluruh tipe
                        laptopTemporary.totalHarga += it.harga * stokLaptopYangDiTambah  // total harga dari seluruh tipe
                    }
                }
            }
            if(!sign){
                laptopListTemporary.tipe.clear()
                println("\n Laptop Tidak Berhasil Ditambahkan !!! ")
                continue
            }
            println("\nLaptop Berhasil Ditambah")
            k++
            financialReports.setMoneyTotal(financialReports.getMoneyTotal() - laptopTemporary.totalHarga)
            financialReports.jsonMoneyTotal = financialReports.gsonPresentableWrite.toJson(financialReports.getMoneyTotalForJson())
            financialReports.fileDataFinancial.writeText(financialReports.jsonMoneyTotal)
            financialReports.getMoneyTotalRp()
            jsonLaptopList = gsonPresentableWrite.toJson(laptopList)
            fileDataLaptop.writeText(jsonLaptopList)        // untuk menulis ulang json sesuai dengan laptopList terbaru

        }
        laptopListTemporary.merek.clear()
        laptopListTemporary.tipe.clear()
        transactionReports.buyingTransactionIn(time(), laptopTemporary.totalTipe, laptopTemporary.totalStok, laptopTemporary.totalHarga )
    }

    fun sellLaptop(financialReports: FinancialReports, transactionReports: TrasactionReports){
        var count:Int
        var k = 0
        var sign:Boolean
        val keuntungan = mutableListOf<Int>()
        val hargaSetelahDitambahKeuntungan = mutableListOf<Long>()
        val merekList = mutableListOf<String>()
        val tipeMap = mutableMapOf(0 to "Default")
        laptopTemporary.totalHarga = 0
        laptopTemporary.totalStok = 0
        laptopTemporary.totalTipe = 0
        laptopTemporary.totalKeutungan = 0

        print("\nBerapa Tipe Yang Akan Dijual : ")
        laptopTemporary.totalTipe = readLine()?.toInt()?:0

        while(k < laptopTemporary.totalTipe){
            count = 1
            sign = true

            for(i in 0 until laptopList.count()){
                if(!merekList.contains(laptopList[i].merek)) {
                    merekList.add(laptopList[i].merek)
                }
            }

            println("\nLaptop Ke-${k+1}")
            println("|------|------------------|")
            println("|  No  |      Merek       |")
            println("|------|------------------|")
            for(i in 0 until merekList.count()){
                System.out.format("|%4d  |   %-15s|\n",i+1, merekList[i])
            }
            println("|------|------------------|")

            print("Merek Laptop Yang Ke          : ")
            var pilihan = readLine()?.toInt()?:0
            if(pilihan > merekList.count() || pilihan < 0){
                println("\nTidak Ada Di Pilihan !!!")
                continue
            }
            pilihan--
            laptopListTemporary.merek.add(merekList[pilihan])

            println("|------|------------------|")
            println("|  No  |       Tipe       |")
            println("|------|------------------|")
            for(i in 0 until laptopList.count()){
                if(laptopListTemporary.merek[k] == laptopList[i].merek){
                    System.out.format("|%4d  |   %-15s|\n",count,laptopList[i].tipe)
                    tipeMap[count] = laptopList[i].tipe  // dari satu agar sama dengan tablenya
                    count++
                }
            }
            println("|------|------------------|")

            print("Tipe Laptop Yang Ke                : ")
            pilihan = readLine()?.toInt()?:0

            if(pilihan > tipeMap.count()-1 || pilihan < 0){
                println("\nTidak Ada Di Pilihan !!!")
                laptopListTemporary.merek.removeLast()
                continue
            }
            laptopListTemporary.tipe.add(tipeMap[pilihan]?:"")

            for(j in 0 until laptopListTemporary.merek.count()-1){   // untuk mengecek apakah laptop yang baru diinput sama dengan laptop yang sebelumnya diinput
                if(laptopListTemporary.merek[j] == laptopListTemporary.merek.last() && laptopListTemporary.tipe[j] == laptopListTemporary.tipe.last()){
                    println("\nLaptop Tersebut Sudah Diinputkan !!!, Masukan Kembali Laptop Dengan Benar")
                    sign = false
                    break
                }
            }

            if(!sign){
                laptopListTemporary.merek.removeLast()
                laptopListTemporary.tipe.removeLast()
                merekList.removeLast()
                continue
            }

            for(j in 0 until laptopList.count()){
                if( laptopListTemporary.merek.last() == laptopList[j].merek &&
                        laptopListTemporary.tipe.last() == laptopList[j].tipe){
                    laptopListTemporary.harga.add(laptopList[j].harga)
                    println("Harga Laptop                       : ${laptopListTemporary.harga.last().toRupiah()}")
                    break
                }
            }

            print("Masukan Keuntungan (Rp)            : ")
            keuntungan.add(readLine()?.toInt()?:0)
            print("Masukan Jumlah Laptop Yang Dijual  : ")
            laptopListTemporary.jumlahYangDiJual.add(readLine()?.toInt()?:0)


            for(j in 0 until laptopList.count()){   //  untuk mengetahui apakah stok mencukupi
                if(laptopListTemporary.merek.last() == laptopList[j].merek &&
                        laptopListTemporary.tipe.last() == laptopList[j].tipe &&
                        laptopListTemporary.jumlahYangDiJual.last() > laptopList[j].stok){
                    sign = false
                    break
                }
            }

            if(!sign){
                laptopListTemporary.merek.removeLast()
                laptopListTemporary.tipe.removeLast()
                laptopListTemporary.harga.removeLast()
                keuntungan.removeLast()
                merekList.removeLast()
                laptopListTemporary.jumlahYangDiJual.removeLast()
                println("\nStok Tidak Mencukupi !!!")
                continue
            }
        k++
        }

        for(i in 0 until laptopTemporary.totalTipe){
            hargaSetelahDitambahKeuntungan.add(laptopListTemporary.harga[i] + keuntungan[i].toLong())
            println("""
                                
            Laptop Ke-${i+1}
            Merek Yang  Dijual : ${laptopListTemporary.merek[i]}
            Tipe Yang   Dijual : ${laptopListTemporary.tipe[i]}
            Harga Asli         : ${laptopListTemporary.harga[i].toRupiah()}
            Harga Yang  Dijual : ${hargaSetelahDitambahKeuntungan[i].toRupiah()}
            Jumlah Yang Dijual : ${laptopListTemporary.jumlahYangDiJual[i]}
            Total Harga        : ${(hargaSetelahDitambahKeuntungan[i] * laptopListTemporary.jumlahYangDiJual[i]).toRupiah()}         
            """.trimIndent())
            laptopTemporary.totalStok += laptopListTemporary.jumlahYangDiJual[i]
            laptopTemporary.totalKeutungan += keuntungan[i] * laptopListTemporary.jumlahYangDiJual[i]
            laptopTemporary.totalHarga += hargaSetelahDitambahKeuntungan[i] * laptopListTemporary.jumlahYangDiJual[i]
        }

        fun kurangiStok(){
            for(i in 0 until laptopTemporary.totalTipe){
                for(j in 0 until laptopList.count()){
                    if(laptopListTemporary.merek[i] == laptopList[j].merek
                        && laptopListTemporary.tipe[i] == laptopList[j].tipe && laptopListTemporary.jumlahYangDiJual[i] <= laptopList[j].stok){
                    laptopList[j].stok -= laptopListTemporary.jumlahYangDiJual[i]
                        if(laptopList[j].stok == 0){
                            laptopList.removeAt(j)
                        }
                }
                }

            }
            println("\nLaptop Anda Berhasil Terjual !!")

            val current = LocalDateTime.now()
            val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS")
            val formatted = current.format(formatter)

            transactionReports.sellingTransactionIn(formatted, laptopTemporary.totalTipe, laptopTemporary.totalStok, laptopTemporary.totalHarga , laptopTemporary.totalKeutungan)
            financialReports.setMoneyTotal(financialReports.getMoneyTotal() + laptopTemporary.totalHarga)
            financialReports.jsonMoneyTotal = financialReports.gsonPresentableWrite.toJson(financialReports.getMoneyTotalForJson())
            financialReports.fileDataFinancial.writeText(financialReports.jsonMoneyTotal)
            jsonLaptopList = gsonPresentableWrite.toJson(laptopList)
            fileDataLaptop.writeText(jsonLaptopList)        // untuk menulis ulang json sesuai dengan laptopList terbaru
        }

        println("\nTotal Harga Semua Laptop             : ${laptopTemporary.totalHarga.toRupiah()}")
        print("Apakah Yakin Akan menjualnya [Y/N]   : ")
        when(readLine()?:""){
            "Y" -> kurangiStok()
            else -> println("\nLaptop Anda Tidak Berhasil Terjual")
        }
        laptopListTemporary.merek.clear()
        laptopListTemporary.tipe.clear()
        laptopListTemporary.harga.clear()
        laptopListTemporary.jumlahYangDiJual.clear()
        keuntungan.clear()
        hargaSetelahDitambahKeuntungan.clear()
        merekList.clear()
    }

    fun sellLaptopAll(financialReports: FinancialReports, transactionReports: TrasactionReports){
        laptopTemporary.totalStok = 0
        laptopTemporary.totalTipe = 0
        laptopTemporary.totalKeutungan = 0
        print("Masukan Keuntungan (Rp)            : ")
        for(i in 0 until laptopList.count()){
            laptopTemporary.totalStok+= laptopList[i].stok
        }
        laptopTemporary.totalTipe = laptopList.count()
        laptopTemporary.totalKeutungan = readLine()?.toLong()?:0
        laptopTemporary.totalKeutungan *= laptopTemporary.totalStok
        laptopTemporary.totalHarga = getAllPrice()
        val hargaSetelahDitambahKeuntungan = laptopTemporary.totalHarga + laptopTemporary.totalKeutungan
        println("""
            
            Total Tipe Semua Laptop   : ${laptopTemporary.totalTipe}
            Total Jumlah Semua Laptop : ${laptopTemporary.totalStok}
            Total Harga Beli Laptop   : ${laptopTemporary.totalHarga.toRupiah()}
            Total Harga Jual Laptop   : ${hargaSetelahDitambahKeuntungan.toRupiah()}
           
        """.trimIndent())
        print("Apakah Yakin Akan Menjualnya [Y/N] : ")
        when(readLine()?:""){
            "Y" -> {
                    val current = LocalDateTime.now()
                    val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS")
                    val formatted = current.format(formatter)

                    transactionReports.sellingTransactionIn(formatted, laptopTemporary.totalTipe, laptopTemporary.totalStok,laptopTemporary.totalHarga, laptopTemporary.totalKeutungan)
                    laptopList.clear()

                    jsonLaptopList = gsonPresentableWrite.toJson(laptopList)
                    fileDataLaptop.writeText(jsonLaptopList)        // untuk menulis ulang json sesuai dengan laptopList terbaru

                    financialReports.setMoneyTotal(financialReports.getMoneyTotal() + hargaSetelahDitambahKeuntungan)
                    financialReports.jsonMoneyTotal = financialReports.gsonPresentableWrite.toJson(financialReports.getMoneyTotalForJson())
                    financialReports.fileDataFinancial.writeText(financialReports.jsonMoneyTotal)

                    println("\nSemua Laptop Anda Berhasil Terjual !!! ")
                    financialReports.getMoneyTotalRp()
            }
            else -> println("\nSemua Laptop Anda Tidak Berhasil Terjual !!! ")
        }

    }

    fun lookLaptopAll(){
        System.out.format("|------------|------------------|---------------------------------|----------|----------|------------------------------------|--------|-------------------|\n")
        System.out.format("|   %-9s|      %-12s|          %-22s |    %-6s|    %-5s |                %-5s               |  %-5s |      %-8s     |\n","Merek","Tipe","Processor","Ram","Rom","Vga","Stok","Harga")
        System.out.format("|------------|------------------|---------------------------------|----------|----------|------------------------------------|--------|-------------------|\n")

        for(i in 0 until laptopList.count()){
            System.out.format("|   %-9s|   %-15s|  %-29s  |%4d GB   |%6d GB |  %-32s  |%6d  |  %15s  |\n",laptopList[i].merek,laptopList[i].tipe,laptopList[i].processor,laptopList[i].ram,laptopList[i].rom,laptopList[i].vga,laptopList[i].stok,laptopList[i].harga.toRupiah())
        }
        System.out.format("|------------|------------------|---------------------------------|----------|----------|------------------------------------|--------|-------------------|\n")

    }

    fun lookLaptopBrand() {
        print("\nMasukan Merek Laptop : ")
        laptopTemporary.merek = readLine() ?: ""

        System.out.format("|------------|------------------|---------------------------------|----------|----------|------------------------------------|--------|-------------------|\n")
        System.out.format("|   %-9s|      %-12s|          %-22s |    %-6s|    %-5s |                %-5s               |  %-5s |      %-8s     |\n","Merek","Tipe","Processor","Ram","Rom","Vga","Stok","Harga")
        System.out.format("|------------|------------------|---------------------------------|----------|----------|------------------------------------|--------|-------------------|\n")

        for(i in 0 until laptopList.count()){
            if(laptopList[i].merek == laptopTemporary.merek)
            System.out.format("|   %-9s|   %-15s|  %-29s  |%4d GB   |%6d GB |  %-32s  |%6d  |  %15s  |\n",laptopList[i].merek,laptopList[i].tipe,laptopList[i].processor,laptopList[i].ram,laptopList[i].rom,laptopList[i].vga,laptopList[i].stok,laptopList[i].harga.toRupiah())
        }
        System.out.format("|------------|------------------|---------------------------------|----------|----------|------------------------------------|--------|-------------------|\n")
    }

    fun lookLaptopRam() {
        println("""
            
            Ingin Seperti Apa :
            1. Sama Dengan
            2. Kurang Dari
            3. Lebih Dari
            
        """.trimIndent())
        print("input : ")
        val pilihan = readLine()?.toInt() ?: 0
        print("Batasan : ")
        val batasan = readLine()?.toInt() ?: 0
        System.out.format("|------------|------------------|---------------------------------|----------|----------|------------------------------------|--------|-------------------|\n")
        System.out.format("|   %-9s|      %-12s|          %-22s |    %-6s|    %-5s |                %-5s               |  %-5s |      %-8s     |\n", "Merek", "Tipe", "Processor", "Ram", "Rom", "Vga", "Stok", "Harga")
        System.out.format("|------------|------------------|---------------------------------|----------|----------|------------------------------------|--------|-------------------|\n")

        for (i in 0 until laptopList.count()) {
            when (pilihan) {
                1 -> {
                    if (laptopList[i].ram == batasan)
                        System.out.format("|   %-9s|   %-15s|  %-29s  |%4d GB   |%6d GB |  %-32s  |%6d  |  %15s  |\n", laptopList[i].merek, laptopList[i].tipe, laptopList[i].processor, laptopList[i].ram, laptopList[i].rom, laptopList[i].vga, laptopList[i].stok, laptopList[i].harga.toRupiah())
                }
                2 -> {
                    if (laptopList[i].ram < batasan)
                        System.out.format("|   %-9s|   %-15s|  %-29s  |%4d GB   |%6d GB |  %-32s  |%6d  |  %15s  |\n", laptopList[i].merek, laptopList[i].tipe, laptopList[i].processor, laptopList[i].ram, laptopList[i].rom, laptopList[i].vga, laptopList[i].stok, laptopList[i].harga.toRupiah())
                }
                3 -> {
                    if (laptopList[i].ram > batasan)
                        System.out.format("|   %-9s|   %-15s|  %-29s  |%4d GB   |%6d GB |  %-32s  |%6d  |  %15s  |\n", laptopList[i].merek, laptopList[i].tipe, laptopList[i].processor, laptopList[i].ram, laptopList[i].rom, laptopList[i].vga, laptopList[i].stok, laptopList[i].harga.toRupiah())
                }
            }

        }
        System.out.format("|------------|------------------|---------------------------------|----------|----------|------------------------------------|--------|-------------------|\n")
    }

    fun lookLaptopRom() {
        println("""
            
            Ingin Seperti Apa :
            1. Sama Dengan
            2. Kurang Dari
            3. Lebih Dari
            
        """.trimIndent())
        print("input : ")
        val pilihan = readLine()?.toInt() ?: 0
        print("Batasan : ")
        val batasan = readLine()?.toInt() ?: 0
        System.out.format("|------------|------------------|---------------------------------|----------|----------|------------------------------------|--------|-------------------|\n")
        System.out.format("|   %-9s|      %-12s|          %-22s |    %-6s|    %-5s |                %-5s               |  %-5s |      %-8s     |\n", "Merek", "Tipe", "Processor", "Ram", "Rom", "Vga", "Stok", "Harga")
        System.out.format("|------------|------------------|---------------------------------|----------|----------|------------------------------------|--------|-------------------|\n")

        for (i in 0 until laptopList.count()) {
            when (pilihan) {
                1 -> {
                    if (laptopList[i].rom == batasan)
                        System.out.format("|   %-9s|   %-15s|  %-29s  |%4d GB   |%6d GB |  %-32s  |%6d  |  %15s  |\n", laptopList[i].merek, laptopList[i].tipe, laptopList[i].processor, laptopList[i].ram, laptopList[i].rom, laptopList[i].vga, laptopList[i].stok, laptopList[i].harga.toRupiah())
                }
                2 -> {
                    if (laptopList[i].rom < batasan)
                        System.out.format("|   %-9s|   %-15s|  %-29s  |%4d GB   |%6d GB |  %-32s  |%6d  |  %15s  |\n", laptopList[i].merek, laptopList[i].tipe, laptopList[i].processor, laptopList[i].ram, laptopList[i].rom, laptopList[i].vga, laptopList[i].stok, laptopList[i].harga.toRupiah())
                }
                3 -> {
                    if (laptopList[i].rom > batasan)
                        System.out.format("|   %-9s|   %-15s|  %-29s  |%4d GB   |%6d GB |  %-32s  |%6d  |  %15s  |\n", laptopList[i].merek, laptopList[i].tipe, laptopList[i].processor, laptopList[i].ram, laptopList[i].rom, laptopList[i].vga, laptopList[i].stok, laptopList[i].harga.toRupiah())
                }
            }

        }
        System.out.format("|------------|------------------|---------------------------------|----------|----------|------------------------------------|--------|-------------------|\n")
    }

    fun lookLaptopPrice() {
        println("""
            
            Ingin Seperti Apa :
            1. Sama Dengan
            2. Kurang Dari
            3. Lebih Dari
            
        """.trimIndent())
        print("input : ")
        val pilihan = readLine()?.toInt() ?: 0
        print("Batasan : ")
        val batasan = readLine()?.toInt() ?: 0
        System.out.format("|------------|------------------|---------------------------------|----------|----------|------------------------------------|--------|-------------------|\n")
        System.out.format("|   %-9s|      %-12s|          %-22s |    %-6s|    %-5s |                %-5s               |  %-5s |      %-8s     |\n", "Merek", "Tipe", "Processor", "Ram", "Rom", "Vga", "Stok", "Harga")
        System.out.format("|------------|------------------|---------------------------------|----------|----------|------------------------------------|--------|-------------------|\n")

        for (i in 0 until laptopList.count()) {
            when (pilihan) {
                1 -> {
                    if (laptopList[i].harga == batasan.toLong())
                        System.out.format("|   %-9s|   %-15s|  %-29s  |%4d GB   |%6d GB |  %-32s  |%6d  |  %15s  |\n", laptopList[i].merek, laptopList[i].tipe, laptopList[i].processor, laptopList[i].ram, laptopList[i].rom, laptopList[i].vga, laptopList[i].stok, laptopList[i].harga.toRupiah())
                }
                2 -> {
                    if (laptopList[i].harga < batasan.toLong())
                        System.out.format("|   %-9s|   %-15s|  %-29s  |%4d GB   |%6d GB |  %-32s  |%6d  |  %15s  |\n", laptopList[i].merek, laptopList[i].tipe, laptopList[i].processor, laptopList[i].ram, laptopList[i].rom, laptopList[i].vga, laptopList[i].stok, laptopList[i].harga.toRupiah())
                }
                3 -> {
                    if (laptopList[i].harga > batasan.toLong())
                        System.out.format("|   %-9s|   %-15s|  %-29s  |%4d GB   |%6d GB |  %-32s  |%6d  |  %15s  |\n", laptopList[i].merek, laptopList[i].tipe, laptopList[i].processor, laptopList[i].ram, laptopList[i].rom, laptopList[i].vga, laptopList[i].stok, laptopList[i].harga.toRupiah())
                }
            }

        }
        System.out.format("|------------|------------------|---------------------------------|----------|----------|------------------------------------|--------|-------------------|\n")
    }

    fun updateLaptop(){
        val merekList = mutableListOf<String>()
        val tipeMap = mutableMapOf(0 to "Default")
        var count:Int
        var k = 0
        var index = 0
        print("\nMasukan Berapa Laptop Yang Ingin Diupdate : ")
        val banyakDiupdate = readLine()?.toInt()?:0

        while(k < banyakDiupdate){
            laptopTemporary.totalStok = 0
            laptopTemporary.totalHarga = 0
            count = 1
            for(i in 0 until laptopList.count()){
                if(!merekList.contains(laptopList[i].merek)) {
                    merekList.add(laptopList[i].merek)
                }
            }

            println("\nLaptop Ke-${k+1}")
            println("|------|------------------|")
            println("|  No  |      Merek       |")
            println("|------|------------------|")
            for(i in 0 until merekList.count()){
                System.out.format("|%4d  |   %-15s|\n",i+1, merekList[i])
            }
            println("|------|------------------|")

            print("Merek Laptop Yang Ke          : ")
            var pilihan = readLine()?.toInt()?:0
            if(pilihan > merekList.count() || pilihan < 0){
                println("\nTidak Ada Di Pilihan !!!")
                continue
            }
            pilihan--
            laptopTemporary.merek = merekList[pilihan]

            println("|------|------------------|")
            println("|  No  |       Tipe       |")
            println("|------|------------------|")
            for(i in 0 until laptopList.count()){
                if(laptopTemporary.merek == laptopList[i].merek){
                    System.out.format("|%4d  |   %-15s|\n",count,laptopList[i].tipe)
                    tipeMap[count] = laptopList[i].tipe
                    count++
                }
            }
            println("|------|------------------|")

            print("Tipe Laptop Yang Ke                        : ")
            pilihan = readLine()?.toInt()?:0      // karena menggunakan map jadi tidak dikurang satu

            if(pilihan > tipeMap.count()-1 || pilihan < 0){
                println("\nTidak Ada Di Pilihan !!!")
                continue
            }
            laptopTemporary.tipe = tipeMap[pilihan]?:""

            for(j in 0 until laptopList.count()){
                if(laptopTemporary.tipe == laptopList[j].tipe && laptopTemporary.merek == laptopList[j].merek){
                    index = j
                    break
                }
            }

            println("\nJika Tidak Ingin Diganti, Ketik '-' ")
            System.out.format("|------------|------------------|---------------------------------|----------|----------|------------------------------------|--------|-------------------|\n")
            System.out.format("|   %-9s|      %-12s|          %-22s |    %-6s|    %-5s |                %-5s               |  %-5s |      %-8s     |\n","Merek","Tipe","Processor","Ram","Rom","Vga","Stok","Harga")
            System.out.format("|------------|------------------|---------------------------------|----------|----------|------------------------------------|--------|-------------------|\n")
            System.out.format("|   %-9s|   %-15s|  %-29s  |%4d GB   |%6d GB |  %-32s  |%6d  |  %15s  |\n",laptopList[index].merek,laptopList[index].tipe,laptopList[index].processor,laptopList[index].ram,laptopList[index].rom,laptopList[index].vga,laptopList[index].stok,laptopList[index].harga.toRupiah())
            System.out.format("|------------|------------------|---------------------------------|----------|----------|------------------------------------|--------|-------------------|\n")

            print("\nmasukan processor : ")
                laptopTemporary.processor = readLine()?:""
                if(laptopTemporary.processor != "-"){
                    laptopList[index].processor = laptopTemporary.processor
                }
                print("masukan Ram       : ")
                laptopTemporary.ramString = readLine()?:""
                if(laptopTemporary.ramString != "-"){
                    laptopList[index].ram = laptopTemporary.ramString.toInt()
                }
                print("masukan Rom       : ")
                laptopTemporary.romString = readLine()?:""
                if(laptopTemporary.romString != "-"){
                    laptopList[index].rom = laptopTemporary.romString.toInt()
                }
                print("masukan Vga       : ")
                laptopTemporary.vga = readLine()?:""
                if(laptopTemporary.vga != "-"){
                    laptopList[index].vga = laptopTemporary.vga
                }
                k++
                jsonLaptopList = gsonPresentableWrite.toJson(laptopList)
                fileDataLaptop.writeText(jsonLaptopList)        // untuk menulis ulang json sesuai dengan laptopList terbaru
                println("\nLaptop Sudah Diupdate !!!")


        }

    }

    fun removeLaptop(financialReports: FinancialReports){
        var index = 0
        var k = 0
        val merekList = mutableListOf<String>()
        val tipeMap = mutableMapOf(0 to "Default")
        var count:Int

        print("\nMasukan Berapa Laptop Yang Ingin Dibuang : ")
        val yangInginDibuang = readLine()?.toInt()?:0

        while (k < yangInginDibuang) {
            laptopTemporary.totalStok = 0
            laptopTemporary.totalHarga = 0
            count = 1
            for(i in 0 until laptopList.count()){
                if(!merekList.contains(laptopList[i].merek)) {
                    merekList.add(laptopList[i].merek)
                }
            }

            println("\nLaptop Ke-${k+1}")
            println("|------|------------------|")
            println("|  No  |      Merek       |")
            println("|------|------------------|")
            for(i in 0 until merekList.count()){
                System.out.format("|%4d  |   %-15s|\n",i+1, merekList[i])
            }
            println("|------|------------------|")

            print("Merek Laptop Yang Ke          : ")
            var pilihan = readLine()?.toInt()?:0
            if(pilihan > merekList.count() || pilihan < 0){
                println("\nTidak Ada Di Pilihan !!!")
                continue
            }
            pilihan--
            laptopTemporary.merek = merekList[pilihan]

            println("|------|------------------|")
            println("|  No  |       Tipe       |")
            println("|------|------------------|")
            for(i in 0 until laptopList.count()){
                if(laptopTemporary.merek == laptopList[i].merek){
                    System.out.format("|%4d  |   %-15s|\n",count,laptopList[i].tipe)
                    tipeMap[count] = laptopList[i].tipe
                    count++
                }
            }
            println("|------|------------------|")

            print("Tipe Laptop Yang Ke                        : ")
            pilihan = readLine()?.toInt()?:0      // karena menggunakan map jadi tidak dikurang satu

            if(pilihan > tipeMap.count()-1 || pilihan < 0){
                println("\nTidak Ada Di Pilihan !!!")
                continue
            }
            laptopTemporary.tipe = tipeMap[pilihan]?:""

            for (i in 0 until laptopList.count()) {
                if (laptopTemporary.merek == laptopList[i].merek && laptopTemporary.tipe == laptopList[i].tipe) {
                    index = i
                    break
                }
            }

            System.out.format("|------------|------------------|---------------------------------|----------|----------|------------------------------------|--------|-------------------|\n")
            System.out.format("|   %-9s|      %-12s|          %-22s |    %-6s|    %-5s |                %-5s               |  %-5s |      %-8s     |\n","Merek","Tipe","Processor","Ram","Rom","Vga","Stok","Harga")
            System.out.format("|------------|------------------|---------------------------------|----------|----------|------------------------------------|--------|-------------------|\n")
            System.out.format("|   %-9s|   %-15s|  %-29s  |%4d GB   |%6d GB |  %-32s  |%6d  |  %15s  |\n",laptopList[index].merek,laptopList[index].tipe,laptopList[index].processor,laptopList[index].ram,laptopList[index].rom,laptopList[index].vga,laptopList[index].stok,laptopList[index].harga.toRupiah())
            System.out.format("|------------|------------------|---------------------------------|----------|----------|------------------------------------|--------|-------------------|\n")

            println("""
                  Pilih
                    
                  1. Membuangnya Saja 
                  2. Membuangnya Dan Uang Pembelian Kembali (Karena Kesalahan Data)
                    
              """.trimIndent())
            print("input : ")
            pilihan = readLine()?.toInt()?:0
            print("\nApakah Anda Yakin : ")
            val sign = readLine()?:""
            if(sign == "Y") {
                when (pilihan) {
                    1 -> {
                        laptopList.removeAt(index)
                        println("Laptop Berhasil DiBuang !!!")
                    }
                    2 -> {
                        println("\nTotal Uang Kembali : ${(laptopList[index].harga * laptopList[index].stok).toRupiah()}")
                        financialReports.setMoneyTotal(financialReports.getMoneyTotal() + (laptopList[index].harga * laptopList[index].stok))
                        laptopList.removeAt(index)
                        println("Laptop Berhasil DiBuang !!!")
                    }
                }
            }
            else{
                println("Laptop Tidak Jadi Dibuang !!!")
                continue
            }
            jsonLaptopList = gsonPresentableWrite.toJson(laptopList)
            financialReports.jsonMoneyTotal = gsonPresentableWrite.toJson(financialReports.getMoneyTotalForJson())
            fileDataLaptop.writeText(jsonLaptopList)
            financialReports.fileDataFinancial.writeText(financialReports.jsonMoneyTotal)
            k++
        }

    }

    fun sortLaptopPrice(){
        var tmp:Laptop
        println("""
            
            Mengurutkan Laptop Berdasarkan Harga
            
            1. Dari Yang Termahal
            2. Dari Yang Termurah
            
        """.trimIndent())
        print("input : ")
        when(readLine()?.toInt()?:0) {
            1 -> {
                for (i in 0 until laptopList.count() - 1) {
                    for (j in i + 1 until laptopList.count()) {
                        if (laptopList[i].harga < laptopList[j].harga) {
                            tmp = laptopList[i]
                            laptopList[i] = laptopList[j]
                            laptopList[j] = tmp
                        }

                    }

                }
            }
            2 -> {
                for (i in 0 until laptopList.count() - 1) {
                    for (j in i + 1 until laptopList.count()) {
                        if (laptopList[i].harga > laptopList[j].harga) {
                            tmp = laptopList[i]
                            laptopList[i] = laptopList[j]
                            laptopList[j] = tmp
                        }

                    }

                }
            }
        }
        jsonLaptopList = gsonPresentableWrite.toJson(laptopList)
        fileDataLaptop.writeText(jsonLaptopList)
        println("Laptop Berhasil Diurutkan !!!")
    }

    fun sortLaptopRam(){
        var tmp:Laptop
        println("""
            
            Mengurutkan Laptop Berdasarkan Ram
            
            1. Dari Yang Tertinggi
            2. Dari Yang Terendah
            
        """.trimIndent())
        print("input : ")
        when(readLine()?.toInt()?:0) {
            1 -> {
                for (i in 0 until laptopList.count() - 1) {
                    for (j in i + 1 until laptopList.count()) {
                        if (laptopList[i].ram < laptopList[j].ram) {
                            tmp = laptopList[i]
                            laptopList[i] = laptopList[j]
                            laptopList[j] = tmp
                        }

                    }

                }
            }
            2 -> {
                for (i in 0 until laptopList.count() - 1) {
                    for (j in i + 1 until laptopList.count()) {
                        if (laptopList[i].ram > laptopList[j].ram) {
                            tmp = laptopList[i]
                            laptopList[i] = laptopList[j]
                            laptopList[j] = tmp
                        }

                    }

                }
            }
        }
        jsonLaptopList = gsonPresentableWrite.toJson(laptopList)
        fileDataLaptop.writeText(jsonLaptopList)
        println("Laptop Berhasil Diurutkan !!!")
    }

    fun sortLaptopRom(){
        var tmp:Laptop
        println("""
            
            Mengurutkan Laptop Berdasarkan Rom
            
            1. Dari Yang Tertinggi
            2. Dari Yang Terendah
            
        """.trimIndent())
        print("input : ")
        when(readLine()?.toInt()?:0) {
            1 -> {
                for (i in 0 until laptopList.count() - 1) {
                    for (j in i + 1 until laptopList.count()) {
                        if (laptopList[i].rom < laptopList[j].rom) {
                            tmp = laptopList[i]
                            laptopList[i] = laptopList[j]
                            laptopList[j] = tmp
                        }

                    }

                }
            }
            2 -> {
                for (i in 0 until laptopList.count() - 1) {
                    for (j in i + 1 until laptopList.count()) {
                        if (laptopList[i].rom > laptopList[j].rom) {
                            tmp = laptopList[i]
                            laptopList[i] = laptopList[j]
                            laptopList[j] = tmp
                        }

                    }

                }
            }
        }
        jsonLaptopList = gsonPresentableWrite.toJson(laptopList)
        fileDataLaptop.writeText(jsonLaptopList)
        println("Laptop Berhasil Diurutkan !!!")
    }

    fun sortLaptopBrand(){
        var tmp:Laptop
        println("""
            
            Mengurutkan Laptop Berdasarkan Brand
            
            1. Ascending
            2. Descending
            
        """.trimIndent())
        print("input : ")
        when(readLine()?.toInt()?:0) {
            1 -> {
                for (i in 0 until laptopList.count() - 1) {
                    for (j in i + 1 until laptopList.count()) {
                        if (laptopList[i].merek > laptopList[j].merek) {
                            tmp = laptopList[i]
                            laptopList[i] = laptopList[j]
                            laptopList[j] = tmp
                        }

                    }

                }
            }
            2 -> {
                for (i in 0 until laptopList.count() - 1) {
                    for (j in i + 1 until laptopList.count()) {
                        if (laptopList[i].merek < laptopList[j].merek) {
                            tmp = laptopList[i]
                            laptopList[i] = laptopList[j]
                            laptopList[j] = tmp
                        }

                    }

                }
            }
        }
        jsonLaptopList = gsonPresentableWrite.toJson(laptopList)
        fileDataLaptop.writeText(jsonLaptopList)
        println("Laptop Berhasil Diurutkan !!!")
    }

}