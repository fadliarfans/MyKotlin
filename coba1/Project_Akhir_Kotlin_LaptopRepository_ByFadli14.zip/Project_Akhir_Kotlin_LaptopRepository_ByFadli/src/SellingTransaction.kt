
data class SellingTransaction(val date: String,
                              val totalTipeYangDijual:Int,
                              val totalLaptopYangDijual:Int,
                              val totalHarga:Long,
                              val totalKeuntungan:Long)