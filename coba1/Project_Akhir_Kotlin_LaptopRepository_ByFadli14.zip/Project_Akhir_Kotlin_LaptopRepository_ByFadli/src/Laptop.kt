data class Laptop(
        val merek:String,
        val tipe:String,
        var processor:String,
        var ram:Int,
        var rom:Int,
        var vga:String,
        var stok:Int,
        var harga:Long)


