class LaptopTemporary{
    var merek:String = ""
    var tipe:String = ""
    var processor:String = ""
    var ram:Int = 0
    var rom:Int = 0
    var vga:String = ""
    var stok:Int = 0
    var harga:Long = 0
    var totalTipe:Int = 0
    var totalHarga:Long = 0
    var totalStok:Int = 0
    var totalKeutungan:Long = 0
    var ramString:String = ""
    var romString:String = ""
}

class LaptopListTemporary{
    var merek = mutableListOf<String>()
    var tipe = mutableListOf<String>()
    var processor = mutableListOf<String>()
    var ram = mutableListOf<Int>()
    var rom = mutableListOf<Int>()
    var vga = mutableListOf<String>()
    var stok = mutableListOf<Int>()
    var harga = mutableListOf<Long>()
    var jumlahYangDiJual = mutableListOf<Int>()
}
