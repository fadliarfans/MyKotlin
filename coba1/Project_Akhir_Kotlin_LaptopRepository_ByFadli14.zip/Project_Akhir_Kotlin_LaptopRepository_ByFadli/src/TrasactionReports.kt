import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.google.gson.reflect.TypeToken
import java.io.File
import java.io.FileReader
import java.text.DecimalFormat
import java.text.NumberFormat


class TrasactionReports {
    private val gson = Gson()
    private val mutableListTypeSelling= object : TypeToken<MutableList<SellingTransaction>>() {}.type!!
    private val mutableListTypeBuying = object : TypeToken<MutableList<BuyingTransaction>>() {}.type!!
    private var sellingTransactionList:MutableList<SellingTransaction> = gson.fromJson(FileReader("src/assets/DataSellingTransaction.json"),mutableListTypeSelling)
    private var buyingTrasactionList:MutableList<BuyingTransaction> = gson.fromJson(FileReader("src/assets/DataBuyingTransaction.json"),mutableListTypeBuying)

    private var fileDataSellingTransaction = File("src/assets/DataSellingTransaction.json")
    private var fileDataBuyingTransaction = File("src/assets/DataBuyingTransaction.json")

    private var gsonPresetableWrite = GsonBuilder().setPrettyPrinting().create()!!
    private var gsonSellingTransactionList = gsonPresetableWrite.toJson(sellingTransactionList)
    private var gsonBuyingTransactionList = gsonPresetableWrite.toJson(buyingTrasactionList)

    private fun Long.toRupiah():String{
        val formatter: NumberFormat = DecimalFormat("#,###")
        val moneyRupiah = formatter.format(this)
        return "Rp $moneyRupiah"
    }

    fun sellingTransactionIn(date: String, totalTipeYangDijual:Int, totalLaptopYangDijual:Int, totalHarga:Long, totalKeuntungan:Long){
        sellingTransactionList.add(SellingTransaction(date, totalTipeYangDijual, totalLaptopYangDijual, totalHarga, totalKeuntungan))
        gsonSellingTransactionList = gsonPresetableWrite.toJson(sellingTransactionList)
        fileDataSellingTransaction.writeText(gsonSellingTransactionList)
    }

    fun buyingTransactionIn(date: String, totalTipeYangDibeli:Int, totalLaptopYangDibeli: Int, totalHarga:Long){
        buyingTrasactionList.add(BuyingTransaction(date, totalTipeYangDibeli, totalLaptopYangDibeli, totalHarga ))
        gsonBuyingTransactionList = gsonPresetableWrite.toJson(buyingTrasactionList)
        fileDataBuyingTransaction.writeText(gsonBuyingTransactionList)
    }

    fun sellingTransactionOut(){
        println(" Transaksi Penjualan Laptop \n")
        System.out.format("|-----------------------------|------------|--------------|-----------------------|-----------------------|---------------------|\n")
        System.out.format("|   %15s           | %10s | %12s | %19s   | %19s   |  %17s  |\n","Tanggal","Total Tipe","Total Laptop","Total Harga Beli","Total Harga Jual","Total Keuntungan")
        System.out.format("|-----------------------------|------------|--------------|-----------------------|-----------------------|---------------------|\n")
        for(i in 0 until sellingTransactionList.count()){
            System.out.format("|   %23s   | %6d     | %7d      | %19s   | %19s   |  %17s  |\n",sellingTransactionList[i].date, sellingTransactionList[i].totalTipeYangDijual, sellingTransactionList[i].totalLaptopYangDijual, (sellingTransactionList[i].totalHarga - sellingTransactionList[i].totalKeuntungan).toRupiah(),sellingTransactionList[i].totalHarga.toRupiah(), sellingTransactionList[i].totalKeuntungan.toRupiah())
        }
        System.out.format("|-----------------------------|------------|--------------|-----------------------|-----------------------|---------------------|\n")
    }

    fun buyingTransactionOut(){
        println(" Transaksi Pembelian Laptop \n")
        System.out.format("|-----------------------------|------------|--------------|---------------------|\n")
        System.out.format("|   %15s           | %10s | %12s | %14s      |\n","Tanggal","Total Tipe","Total Laptop","Total Harga")
        System.out.format("|-----------------------------|------------|--------------|---------------------|\n")
        for(i in 0 until buyingTrasactionList.count()){
            System.out.format("|   %23s   | %6d     | %7d      | %17s   |\n",buyingTrasactionList[i].date, buyingTrasactionList[i].totalTipeYangDibeli, buyingTrasactionList[i].totalLaptopYangDibeli, buyingTrasactionList[i].totalHarga.toRupiah())
        }
        System.out.format("|-----------------------------|------------|--------------|---------------------|\n")
    }
}