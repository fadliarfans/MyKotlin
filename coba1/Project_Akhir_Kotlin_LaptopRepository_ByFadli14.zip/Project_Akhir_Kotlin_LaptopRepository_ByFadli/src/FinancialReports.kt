import java.io.FileReader
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.google.gson.reflect.TypeToken
import java.io.File
import java.text.DecimalFormat
import java.text.NumberFormat

class FinancialReports {
    private val gson = Gson()
    private val financialType = object : TypeToken<MutableList<Financial>>() {}.type!!    // untuk mendefinisikan tipe

    private var moneyTotal:MutableList<Financial> = gson.fromJson(FileReader("src/assets/DataFinancial.json"), financialType)    // untuk menguraikan json menjadi list
    private var wealthTotal = Financial()

    var fileDataFinancial = File("src/assets/DataFinancial.json")          // deklarasi file

    val gsonPresentableWrite = GsonBuilder().setPrettyPrinting().create()!!      // untuk mengubah list berisi objek menjadi json string yang mudah dibaca
    var jsonMoneyTotal: String = gsonPresentableWrite.toJson(moneyTotal)

    private fun Long.toRupiah():String{
        val formatter: NumberFormat = DecimalFormat("#,###")
        val moneyRupiah = formatter.format(this)
        return "Rp $moneyRupiah"
    }

    fun getMoneyTotalForJson(): MutableList<Financial> {
        return moneyTotal
    }

    fun getMoneyTotalRp(){
        println("\nTotal Uang Kas : ${moneyTotal[0].money.toRupiah()}")
    }

    fun getMoneyTotal():Long{
        return moneyTotal[0].money
    }

    fun getWealthTotalRp(){
        println("\nTotal Kekayaan : ${wealthTotal.money.toRupiah()}")
    }

    fun setMoneyTotal(value:Long){
        moneyTotal[0].money = value
    }

    fun setWealthTotal(repositoryLaptop: RepositoryLaptop) {
        wealthTotal.money =  repositoryLaptop.getAllPrice() + moneyTotal[0].money
    }

    fun plusMoneyTotal(){
        print("\nMasukan Uang Yang Ingin Ditambahkan : ")
        val plus = readLine()?.toLong()?:0
        moneyTotal[0].money += plus
        println("\nUang Berhasil Ditambahkan !!! ")
        jsonMoneyTotal = gsonPresentableWrite.toJson(moneyTotal)
        fileDataFinancial.writeText(jsonMoneyTotal)
    }

    fun minusMoneyTotal(){
        print("\nMasukan Uang Yang Ingin Diambil     : ")
        val minus = readLine()?.toLong()?:0
        moneyTotal[0].money -= minus
        println("\nUang Berhasil Diambil !!! ")
        jsonMoneyTotal = gsonPresentableWrite.toJson(moneyTotal)
        fileDataFinancial.writeText(jsonMoneyTotal)
    }



}