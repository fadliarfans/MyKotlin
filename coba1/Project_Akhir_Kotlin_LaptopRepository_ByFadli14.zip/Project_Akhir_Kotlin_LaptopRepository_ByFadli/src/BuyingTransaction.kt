
data class BuyingTransaction(val date: String,
                             val totalTipeYangDibeli:Int,
                             val totalLaptopYangDibeli: Int,
                             val totalHarga:Long)