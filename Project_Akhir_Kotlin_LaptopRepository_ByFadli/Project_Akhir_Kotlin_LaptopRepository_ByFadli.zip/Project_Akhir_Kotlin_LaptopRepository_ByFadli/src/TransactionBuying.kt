
data class TransactionBuying(val date: String,
                             val totalTipeYangDibeli:Int,
                             val totalLaptopYangDibeli: Int,
                             val totalHarga:Long,
                             val laptopListBackup:LaptopPrimaryList)