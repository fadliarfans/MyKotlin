data class Laptop(var merek:String,
                  var tipe:String,
                  var processor:String,
                  var ram:Int,
                  var rom:Int,
                  var vga:String,
                  var stok:Int,
                  var harga:Long,
                  var date:String)




