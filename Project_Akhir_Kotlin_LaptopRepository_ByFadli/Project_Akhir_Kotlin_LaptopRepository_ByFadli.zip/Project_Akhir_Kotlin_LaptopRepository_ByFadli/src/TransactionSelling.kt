
data class TransactionSelling(val date: String,
                              val totalTipeYangDijual:Int,
                              val totalLaptopYangDijual:Int,
                              val totalHarga:Long,
                              val totalKeuntungan:Long,
                              val laptopListBackup:LaptopPrimaryList)
