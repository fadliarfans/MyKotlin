open class LaptopPrimary {
    var merek:String = ""
    var tipe:String = ""
    var stok:Int = 0
}