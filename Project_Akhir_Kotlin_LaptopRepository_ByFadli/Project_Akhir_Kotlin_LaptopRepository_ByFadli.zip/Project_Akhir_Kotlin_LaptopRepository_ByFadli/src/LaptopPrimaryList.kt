class LaptopPrimaryList {
    var list = mutableListOf<LaptopPrimary>()
}