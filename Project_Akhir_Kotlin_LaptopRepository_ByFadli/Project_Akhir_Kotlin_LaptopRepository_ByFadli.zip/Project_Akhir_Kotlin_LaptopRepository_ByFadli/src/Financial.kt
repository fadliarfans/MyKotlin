
class Financial {
    var money:Long = 0
}