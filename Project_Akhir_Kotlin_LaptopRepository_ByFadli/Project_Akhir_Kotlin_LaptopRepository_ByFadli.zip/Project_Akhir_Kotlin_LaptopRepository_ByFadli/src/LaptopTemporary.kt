class LaptopTemporary: LaptopPrimary() {
    var processor:String = ""
    var ram:Int = 0
    var rom:Int = 0
    var vga:String = ""
    var harga:Long = 0
    var totalTipe:Int = 0
    var totalHarga:Long = 0
    var totalStok:Int = 0
    var totalKeuntungan:Long = 0
    var ramString:String = ""
    var romString:String = ""
}





